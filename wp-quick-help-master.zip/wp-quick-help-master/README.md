Wordpress Quick Help 
***

[![Screnshot](https://raw.github.com/rm2334/wp-quick-help/master/asset/img/screenshot.jpg "Screenshot Preview")](https://github.com/rm2334/wp-quick-help)


এটা বানিয়েছি আমার নিজের আর্কাইভের জন্য, যাতে আমি চট জলদি এখান থেকে সাহায্য নিতে পারি।
আপনারাও ইচ্ছা করলে ব্যবহার করতে পারেন , এটা সবার জন্য উন্মক্ত।

> এই Wordpress Quick Help  ফাইলে কোন কোড  ভুল দেথা গেলে ভুলটি দেখিয়ে দেবার জন্য অনুরোধ করা হল

ওয়ার্ডপ্রেস থিমস বানানোর ক্ষেত্রে প্রয়োজনীয় প্লাগিনস

[TGM Plugin Activation](http://tgmpluginactivation.com "TGM Plugin Activation")

[Options-Framework](https://github.com/syamilmj/Options-Framework "Options-Framework")

[Custom-Metaboxes-and-Fields-for-WordPress](https://github.com/WebDevStudios/Custom-Metaboxes-and-Fields-for-WordPress "Custom-Metaboxes-and-Fields-for-WordPress")
